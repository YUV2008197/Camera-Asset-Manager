package com.procam.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.lifecycle.lifecycleScope
import com.procam.app.camera.CameraController
import com.procam.app.camera.CaptureMode
import com.procam.app.databinding.ActivityMainBinding
import com.procam.app.processing.ImagePipeline
import kotlinx.coroutines.launch

/**
 * Main entry point. Hosts the live preview, manual controls, and mode switcher.
 *
 * Architecture:
 *  - CameraController  : Camera2 session lifecycle, RAW+YUV+JPEG capture, ZSL ring buffer.
 *  - ImagePipeline     : multi-frame HDR merge, night-mode stack, tone mapping, bokeh.
 *  - HistogramView     : live luminance histogram from preview YUV frames.
 *  - AutoFitTextureView: aspect-ratio-correct preview surface.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var camera: CameraController
    private lateinit var pipeline: ImagePipeline
    private var mode: CaptureMode = CaptureMode.PHOTO

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        pipeline = ImagePipeline(applicationContext)
        camera = CameraController(this, pipeline) { yuv ->
            binding.histogramView.updateFromYuv(yuv)
        }

        setupControls()
        ensurePermissions()
    }

    private fun setupControls() {
        binding.shutterBtn.setOnClickListener {
            lifecycleScope.launch {
                when (mode) {
                    CaptureMode.PHOTO    -> camera.captureSinglePhoto()
                    CaptureMode.HDR      -> camera.captureHdrBurst(frameCount = 5)
                    CaptureMode.NIGHT    -> camera.captureNightStack(frameCount = 7)
                    CaptureMode.PORTRAIT -> camera.capturePortrait()
                    CaptureMode.VIDEO    -> camera.toggleVideoRecording()
                }
            }
        }

        binding.modePhoto.setOnClickListener    { mode = CaptureMode.PHOTO;    toast("Photo") }
        binding.modeHdr.setOnClickListener      { mode = CaptureMode.HDR;      toast("HDR") }
        binding.modeNight.setOnClickListener    { mode = CaptureMode.NIGHT;    toast("Night") }
        binding.modePortrait.setOnClickListener { mode = CaptureMode.PORTRAIT; toast("Portrait") }
        binding.modeVideo.setOnClickListener    { mode = CaptureMode.VIDEO;    toast("Video") }

        // Manual ISO (mapped to sensor range in CameraController.applyManualIso)
        binding.isoSeek.max = 100
        binding.isoSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                val iso = camera.applyManualIso(p / 100f)
                binding.isoLabel.text = "ISO: $iso"
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })

        // Manual shutter speed
        binding.shutterSeek.max = 100
        binding.shutterSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                val ns = camera.applyManualShutter(p / 100f)
                binding.shutterLabel.text = "SS: 1/${(1_000_000_000.0 / ns).toInt()}s"
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })

        // Manual focus distance (0 = infinity)
        binding.focusSeek.max = 100
        binding.focusSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                val d = camera.applyManualFocus(p / 100f)
                binding.focusLabel.text = "Focus: ${"%.2f".format(d)}"
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
    }

    private fun ensurePermissions() {
        val perms = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
        val missing = perms.any { ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing) ActivityCompat.requestPermissions(this, perms, 1001) else openCamera()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1001 && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) openCamera()
        else toast("Camera permission required")
    }

    private fun openCamera() {
        camera.bindPreview(binding.textureView)
        camera.start()
    }

    override fun onPause() {
        camera.stop()
        super.onPause()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
