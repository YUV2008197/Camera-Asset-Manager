package com.procam.app.camera

import android.media.Image

/** Convert Image (YUV_420_888) into a contiguous NV21 byte array. */
object YuvUtil {
    fun yuv420ToNV21(image: Image): ByteArray {
        val w = image.width; val h = image.height
        val ySize = w * h
        val uvSize = w * h / 2
        val out = ByteArray(ySize + uvSize)

        // Y plane
        val yPlane = image.planes[0]
        val yBuf = yPlane.buffer
        val yRowStride = yPlane.rowStride
        var pos = 0
        for (row in 0 until h) {
            yBuf.position(row * yRowStride)
            yBuf.get(out, pos, w)
            pos += w
        }

        // Interleave V then U for NV21
        val uPlane = image.planes[1]; val vPlane = image.planes[2]
        val uBuf = uPlane.buffer; val vBuf = vPlane.buffer
        val uRowStride = uPlane.rowStride; val uPixelStride = uPlane.pixelStride
        val vRowStride = vPlane.rowStride; val vPixelStride = vPlane.pixelStride
        for (row in 0 until h / 2) {
            for (col in 0 until w / 2) {
                val uIdx = row * uRowStride + col * uPixelStride
                val vIdx = row * vRowStride + col * vPixelStride
                out[pos++] = vBuf.get(vIdx)
                out[pos++] = uBuf.get(uIdx)
            }
        }
        return out
    }
}
