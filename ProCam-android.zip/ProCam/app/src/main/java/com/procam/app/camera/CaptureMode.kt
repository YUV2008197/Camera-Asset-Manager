package com.procam.app.camera

enum class CaptureMode { PHOTO, HDR, NIGHT, PORTRAIT, VIDEO }
