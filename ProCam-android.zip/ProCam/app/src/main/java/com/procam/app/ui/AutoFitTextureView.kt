package com.procam.app.ui

import android.content.Context
import android.util.AttributeSet
import android.view.TextureView

/** TextureView that preserves the camera preview aspect ratio. */
class AutoFitTextureView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyle: Int = 0
) : TextureView(context, attrs, defStyle) {

    private var ratioW = 0
    private var ratioH = 0

    fun setAspectRatio(w: Int, h: Int) {
        require(w > 0 && h > 0)
        ratioW = w; ratioH = h; requestLayout()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val h = MeasureSpec.getSize(heightMeasureSpec)
        if (ratioW == 0 || ratioH == 0) { setMeasuredDimension(w, h); return }
        if (w < h * ratioW / ratioH) setMeasuredDimension(w, w * ratioH / ratioW)
        else setMeasuredDimension(h * ratioW / ratioH, h)
    }
}
