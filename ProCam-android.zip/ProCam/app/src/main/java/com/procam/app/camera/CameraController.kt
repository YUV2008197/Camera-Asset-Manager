package com.procam.app.camera

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.ImageFormat
import android.graphics.SurfaceTexture
import android.hardware.camera2.*
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.SessionConfiguration
import android.media.Image
import android.media.ImageReader
import android.media.MediaRecorder
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.util.Range
import android.util.Size
import android.view.Surface
import com.procam.app.processing.ImagePipeline
import com.procam.app.ui.AutoFitTextureView
import kotlinx.coroutines.*
import java.util.ArrayDeque
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

/**
 * Owns the Camera2 session.
 *
 * Pipelines:
 *   Preview surface (TextureView)
 *   YUV ImageReader (ZSL ring buffer, also feeds histogram + scene analysis)
 *   RAW ImageReader (DNG capture for HDR/Night merging)
 *   JPEG ImageReader (final JPEG fallback)
 *
 * ZSL: a small ring buffer of recent YUV frames is kept; a "shutter press" pulls
 * the most recent in-focus frame instantly with zero shutter lag.
 */
class CameraController(
    private val context: Context,
    private val pipeline: ImagePipeline,
    private val onPreviewFrame: (Image) -> Unit
) {
    companion object { private const val TAG = "CameraController" }

    private val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private var cameraId: String = ""
    private var characteristics: CameraCharacteristics? = null

    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null

    private lateinit var previewView: AutoFitTextureView
    private var previewSurface: Surface? = null

    private var yuvReader: ImageReader? = null
    private var rawReader: ImageReader? = null
    private var jpegReader: ImageReader? = null

    private val cameraThread = HandlerThread("CameraThread").apply { start() }
    private val cameraHandler = Handler(cameraThread.looper)
    private val ioScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val sessionExecutor = Executors.newSingleThreadExecutor()

    /** ZSL buffer of recent YUV frames (most recent at head). */
    private val zslBuffer = ArrayDeque<YuvFrame>(8)
    private val zslLock = Any()

    private var manualIso: Int? = null
    private var manualExposureNs: Long? = null
    private var manualFocusDiopters: Float? = null

    private var mediaRecorder: MediaRecorder? = null
    private var isRecording = false

    fun bindPreview(view: AutoFitTextureView) { this.previewView = view }

    @SuppressLint("MissingPermission")
    fun start() {
        cameraId = pickBackCameraWithRaw() ?: cm.cameraIdList.first()
        characteristics = cm.getCameraCharacteristics(cameraId)

        val map = characteristics!!.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
        val previewSize = chooseSize(map.getOutputSizes(SurfaceTexture::class.java), 1920, 1080)
        val yuvSize     = chooseSize(map.getOutputSizes(ImageFormat.YUV_420_888), 1920, 1080)
        val rawSizes    = map.getOutputSizes(ImageFormat.RAW_SENSOR)
        val jpegSize    = chooseSize(map.getOutputSizes(ImageFormat.JPEG), 4032, 3024)

        previewView.setAspectRatio(previewSize.width, previewSize.height)
        if (previewView.isAvailable) configure(previewSize, yuvSize, rawSizes, jpegSize)
        else previewView.surfaceTextureListener = object : android.view.TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(s: SurfaceTexture, w: Int, h: Int) {
                configure(previewSize, yuvSize, rawSizes, jpegSize)
            }
            override fun onSurfaceTextureSizeChanged(s: SurfaceTexture, w: Int, h: Int) {}
            override fun onSurfaceTextureDestroyed(s: SurfaceTexture) = true
            override fun onSurfaceTextureUpdated(s: SurfaceTexture) {}
        }
    }

    private fun pickBackCameraWithRaw(): String? {
        for (id in cm.cameraIdList) {
            val c = cm.getCameraCharacteristics(id)
            val facing = c.get(CameraCharacteristics.LENS_FACING)
            val caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: intArrayOf()
            val hasRaw = caps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_RAW)
            if (facing == CameraCharacteristics.LENS_FACING_BACK && hasRaw) return id
        }
        return null
    }

    private fun chooseSize(sizes: Array<Size>?, targetW: Int, targetH: Int): Size {
        if (sizes.isNullOrEmpty()) return Size(targetW, targetH)
        return sizes.minBy { kotlin.math.abs(it.width * it.height - targetW * targetH) }
    }

    @SuppressLint("MissingPermission")
    private fun configure(preview: Size, yuv: Size, raw: Array<Size>?, jpeg: Size) {
        val st = previewView.surfaceTexture!!
        st.setDefaultBufferSize(preview.width, preview.height)
        previewSurface = Surface(st)

        yuvReader = ImageReader.newInstance(yuv.width, yuv.height, ImageFormat.YUV_420_888, 6).apply {
            setOnImageAvailableListener({ reader ->
                val img = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
                try {
                    onPreviewFrame(img)
                    pushZsl(img)
                } finally { img.close() }
            }, cameraHandler)
        }

        if (!raw.isNullOrEmpty()) {
            val rawSize = raw.first()
            rawReader = ImageReader.newInstance(rawSize.width, rawSize.height, ImageFormat.RAW_SENSOR, 8).apply {
                setOnImageAvailableListener({ r ->
                    r.acquireNextImage()?.let { pipeline.onRawFrame(it, characteristics!!) }
                }, cameraHandler)
            }
        }

        jpegReader = ImageReader.newInstance(jpeg.width, jpeg.height, ImageFormat.JPEG, 4).apply {
            setOnImageAvailableListener({ r ->
                r.acquireNextImage()?.let { pipeline.onJpegFrame(it) }
            }, cameraHandler)
        }

        cm.openCamera(cameraId, object : CameraDevice.StateCallback() {
            override fun onOpened(d: CameraDevice) { device = d; createSession() }
            override fun onDisconnected(d: CameraDevice) { d.close(); device = null }
            override fun onError(d: CameraDevice, e: Int) { d.close(); device = null }
        }, cameraHandler)
    }

    private fun createSession() {
        val d = device ?: return
        val outputs = listOfNotNull(
            previewSurface?.let { OutputConfiguration(it) },
            yuvReader?.let { OutputConfiguration(it.surface) },
            rawReader?.let { OutputConfiguration(it.surface) },
            jpegReader?.let { OutputConfiguration(it.surface) }
        )
        val cfg = SessionConfiguration(
            SessionConfiguration.SESSION_REGULAR,
            outputs,
            sessionExecutor,
            object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) { session = s; startPreview() }
                override fun onConfigureFailed(s: CameraCaptureSession) { Log.e(TAG, "session failed") }
            }
        )
        d.createCaptureSession(cfg)
    }

    private fun startPreview() {
        val d = device ?: return
        val s = session ?: return
        val req = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
            previewSurface?.let { addTarget(it) }
            yuvReader?.surface?.let { addTarget(it) }
            applyManualOverrides(this)
        }
        s.setRepeatingRequest(req.build(), null, cameraHandler)
    }

    /** Apply current manual overrides (ISO/SS/Focus) to a request. */
    private fun applyManualOverrides(b: CaptureRequest.Builder) {
        val manualSomething = manualIso != null || manualExposureNs != null || manualFocusDiopters != null
        if (manualSomething) {
            b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            manualIso?.let { b.set(CaptureRequest.SENSOR_SENSITIVITY, it) }
            manualExposureNs?.let { b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, it) }
            manualFocusDiopters?.let {
                b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
                b.set(CaptureRequest.LENS_FOCUS_DISTANCE, it)
            }
        }
    }

    // ----- ZSL ring buffer -----
    private data class YuvFrame(val timestamp: Long, val width: Int, val height: Int, val bytes: ByteArray)

    private fun pushZsl(img: Image) {
        val bytes = YuvUtil.yuv420ToNV21(img)
        val frame = YuvFrame(System.nanoTime(), img.width, img.height, bytes)
        synchronized(zslLock) {
            zslBuffer.addFirst(frame)
            while (zslBuffer.size > 6) zslBuffer.removeLast()
        }
    }

    // ---------------- Capture entry points ----------------

    suspend fun captureSinglePhoto() = withContext(Dispatchers.IO) {
        val zsl = synchronized(zslLock) { zslBuffer.peekFirst() }
        if (zsl != null) {
            // Zero shutter lag: process the most recent in-buffer frame instantly.
            pipeline.processSingleNv21(zsl.bytes, zsl.width, zsl.height)
        } else {
            triggerStillJpeg()
        }
    }

    suspend fun captureHdrBurst(frameCount: Int) = withContext(Dispatchers.IO) {
        val brackets = computeExposureBrackets(frameCount)
        captureBurstWithExposures(brackets) { frames ->
            pipeline.processHdr(frames)
        }
    }

    suspend fun captureNightStack(frameCount: Int) = withContext(Dispatchers.IO) {
        // Night mode: long exposures at fixed ISO, then temporal denoise + stack.
        val expNs = 250_000_000L // 1/4s per frame
        val isoFloor = sensorIsoRange().lower
        val brackets = List(frameCount) { Pair(isoFloor * 2, expNs) }
        captureBurstWithExposures(brackets) { frames -> pipeline.processNight(frames) }
    }

    suspend fun capturePortrait() = withContext(Dispatchers.IO) {
        val zsl = synchronized(zslLock) { zslBuffer.peekFirst() } ?: return@withContext
        pipeline.processPortrait(zsl.bytes, zsl.width, zsl.height)
    }

    fun toggleVideoRecording() {
        if (isRecording) stopVideo() else startVideo()
    }

    // ---------------- Capture internals ----------------

    private fun computeExposureBrackets(n: Int): List<Pair<Int, Long>> {
        val isoRange = sensorIsoRange()
        val expRange = sensorExposureRange()
        val baseIso = ((isoRange.lower + isoRange.upper) / 4)
        val baseExp = 1_000_000_00L / 60 // ~1/60s
        // Symmetric EV bracket: -2, -1, 0, +1, +2 (clamped)
        val mid = n / 2
        return List(n) { i ->
            val ev = i - mid
            val mult = Math.pow(2.0, ev.toDouble())
            val exp = (baseExp * mult).toLong().coerceIn(expRange.lower, expRange.upper)
            Pair(baseIso, exp)
        }
    }

    private fun sensorIsoRange(): Range<Int> =
        characteristics?.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE) ?: Range(100, 1600)

    private fun sensorExposureRange(): Range<Long> =
        characteristics?.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE) ?: Range(125_000L, 1_000_000_000L)

    private fun captureBurstWithExposures(
        brackets: List<Pair<Int, Long>>,
        onComplete: (List<ByteArray>) -> Unit
    ) {
        val d = device ?: return
        val s = session ?: return
        val captured = mutableListOf<ByteArray>()
        val expected = brackets.size

        // Reroute jpegReader to collect into our list for this burst.
        val originalListener = { _: ImageReader -> }
        jpegReader?.setOnImageAvailableListener({ r ->
            val img = r.acquireNextImage() ?: return@setOnImageAvailableListener
            try {
                val buf = img.planes[0].buffer
                val data = ByteArray(buf.remaining()); buf.get(data)
                captured.add(data)
                if (captured.size >= expected) {
                    onComplete(captured.toList())
                    // restore default JPEG handler
                    jpegReader?.setOnImageAvailableListener({ rr ->
                        rr.acquireNextImage()?.let { pipeline.onJpegFrame(it) }
                    }, cameraHandler)
                }
            } finally { img.close() }
        }, cameraHandler)

        val requests = brackets.map { (iso, exp) ->
            d.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
                jpegReader?.surface?.let { addTarget(it) }
                rawReader?.surface?.let { addTarget(it) }
                set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
                set(CaptureRequest.SENSOR_SENSITIVITY, iso)
                set(CaptureRequest.SENSOR_EXPOSURE_TIME, exp)
                set(CaptureRequest.NOISE_REDUCTION_MODE, CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY)
                set(CaptureRequest.EDGE_MODE, CaptureRequest.EDGE_MODE_HIGH_QUALITY)
            }.build()
        }
        s.captureBurst(requests, null, cameraHandler)
    }

    private fun triggerStillJpeg() {
        val d = device ?: return
        val s = session ?: return
        val req = d.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
            jpegReader?.surface?.let { addTarget(it) }
            applyManualOverrides(this)
        }.build()
        s.capture(req, null, cameraHandler)
    }

    private fun startVideo() {
        // Simplified video setup; full EIS/LUT pipeline would render via OpenGL into MediaCodec.
        mediaRecorder = MediaRecorder(context).apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setVideoSource(MediaRecorder.VideoSource.SURFACE)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setVideoSize(3840, 2160)
            setVideoFrameRate(30)
            setVideoEncodingBitRate(60_000_000)
            setOutputFile(java.io.File(context.getExternalFilesDir(null), "video_${System.currentTimeMillis()}.mp4").absolutePath)
            prepare()
        }
        // NOTE: a full implementation re-creates the session including MediaRecorder.surface.
        mediaRecorder?.start()
        isRecording = true
    }

    private fun stopVideo() {
        runCatching {
            mediaRecorder?.stop()
            mediaRecorder?.release()
        }
        mediaRecorder = null
        isRecording = false
    }

    // ---------------- Manual control entry points ----------------

    /** Map normalized 0..1 slider to clamped sensor ISO. Returns the chosen ISO. */
    fun applyManualIso(norm: Float): Int {
        val r = sensorIsoRange()
        val iso = (r.lower + (r.upper - r.lower) * norm).toInt().coerceIn(r.lower, r.upper)
        manualIso = iso
        startPreview()
        return iso
    }

    /** Map normalized 0..1 to exposure time (logarithmic). Returns ns. */
    fun applyManualShutter(norm: Float): Long {
        val r = sensorExposureRange()
        val lo = r.lower.toDouble(); val hi = min(r.upper, 1_000_000_000L).toDouble()
        val ns = Math.exp(Math.log(lo) + (Math.log(hi) - Math.log(lo)) * norm).toLong()
        manualExposureNs = ns
        startPreview()
        return ns
    }

    /** Map normalized 0..1 to focus distance (diopters). 0 = infinity. */
    fun applyManualFocus(norm: Float): Float {
        val maxD = characteristics?.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 5f
        val d = norm * maxD
        manualFocusDiopters = d
        startPreview()
        return d
    }

    fun stop() {
        runCatching { session?.close() }
        runCatching { device?.close() }
        runCatching { yuvReader?.close() }
        runCatching { rawReader?.close() }
        runCatching { jpegReader?.close() }
        session = null; device = null
        yuvReader = null; rawReader = null; jpegReader = null
    }
}
