package com.procam.app.ui

import android.content.Context
import android.graphics.*
import android.media.Image
import android.util.AttributeSet
import android.view.View
import java.nio.ByteBuffer

/**
 * Live luminance histogram drawn from YUV_420_888 preview frames.
 * Updates are downsampled (every Nth pixel) to keep cost low on the main thread.
 */
class HistogramView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private val bins = IntArray(64)
    private val barPaint = Paint().apply { color = Color.WHITE; alpha = 200 }
    private val bgPaint  = Paint().apply { color = Color.argb(140, 0, 0, 0) }

    fun updateFromYuv(image: Image) {
        val y: ByteBuffer = image.planes[0].buffer
        val rowStride = image.planes[0].rowStride
        val w = image.width; val h = image.height
        val tmp = IntArray(64)
        // Sample ~10k pixels max
        val stepX = maxOf(1, w / 100)
        val stepY = maxOf(1, h / 100)
        var row = 0
        while (row < h) {
            val base = row * rowStride
            var col = 0
            while (col < w) {
                val v = y.get(base + col).toInt() and 0xFF
                tmp[v ushr 2]++
                col += stepX
            }
            row += stepY
        }
        synchronized(bins) {
            for (i in bins.indices) bins[i] = (bins[i] * 3 + tmp[i]) / 4 // smooth
        }
        postInvalidate()
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)
        val maxV = (bins.max().takeIf { it > 0 } ?: 1).toFloat()
        val bw = width / bins.size.toFloat()
        for (i in bins.indices) {
            val bh = (bins[i] / maxV) * height
            canvas.drawRect(i * bw, height - bh, (i + 1) * bw - 1, height.toFloat(), barPaint)
        }
    }
}
