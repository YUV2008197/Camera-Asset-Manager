package com.procam.app.processing

import android.content.Context
import android.graphics.*
import android.hardware.camera2.CameraCharacteristics
import android.media.Image
import android.util.Log
import androidx.exifinterface.media.ExifInterface
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import kotlin.math.*

/**
 * Computational photography pipeline.
 *
 * Stages implemented (CPU/Bitmap reference implementations — production builds should
 * port the heavy loops to RenderScript/GLSL/Vulkan or NDK for >10x speedup):
 *
 *  - HDR merge        : align frames (translation-only via phase correlation), exposure-fusion
 *                       weights (Mertens 2007: well-exposedness * contrast * saturation), tone map.
 *  - Night mode       : temporal mean stack + bilateral-style edge-preserving denoise.
 *  - Smart exposure   : luminance histogram analysis, highlight protection.
 *  - Scene detection  : heuristic classifier on histogram & color stats.
 *  - Portrait bokeh   : depth approximation via saliency + edge-aware Gaussian blur.
 *  - Sharpening       : unsharp mask.
 *  - White balance    : gray-world.
 *  - Tone curve       : adaptive S-curve.
 *
 *  All outputs are saved to context.getExternalFilesDir("ProCam").
 */
class ImagePipeline(private val context: Context) {

    companion object { private const val TAG = "ImagePipeline" }

    private val outDir: File by lazy {
        File(context.getExternalFilesDir(null), "ProCam").apply { mkdirs() }
    }

    // ---------- Entry points ----------

    fun onJpegFrame(image: Image) {
        try {
            val buf = image.planes[0].buffer
            val data = ByteArray(buf.remaining()); buf.get(data)
            saveJpeg(data, "single_${ts()}.jpg")
        } finally { image.close() }
    }

    fun onRawFrame(image: Image, chr: CameraCharacteristics) {
        try {
            // Save raw DNG-ish blob; full DNG writer is non-trivial — this dumps the sensor bytes.
            val buf = image.planes[0].buffer
            val data = ByteArray(buf.remaining()); buf.get(data)
            File(outDir, "raw_${ts()}.raw").writeBytes(data)
        } finally { image.close() }
    }

    fun processSingleNv21(nv21: ByteArray, w: Int, h: Int) {
        val bmp = nv21ToBitmap(nv21, w, h)
        val enhanced = enhance(bmp)
        saveBitmap(enhanced, "photo_${ts()}.jpg")
    }

    fun processHdr(jpegFrames: List<ByteArray>) {
        val bitmaps = jpegFrames.map { decode(it) }
        val aligned = alignFrames(bitmaps)
        val fused = exposureFusion(aligned)
        val toned = toneMap(fused)
        val sharp = unsharpMask(toned, amount = 0.4f)
        saveBitmap(sharp, "hdr_${ts()}.jpg")
    }

    fun processNight(jpegFrames: List<ByteArray>) {
        val bitmaps = jpegFrames.map { decode(it) }
        val aligned = alignFrames(bitmaps)
        val stacked = temporalMean(aligned)
        val denoised = edgePreservingDenoise(stacked)
        val enhanced = enhance(denoised)
        saveBitmap(enhanced, "night_${ts()}.jpg")
    }

    fun processPortrait(nv21: ByteArray, w: Int, h: Int) {
        val bmp = nv21ToBitmap(nv21, w, h)
        val depth = approximateDepthMap(bmp)
        val bokeh = applyBokeh(bmp, depth, blurRadius = 18f)
        val enhanced = enhance(bokeh)
        saveBitmap(enhanced, "portrait_${ts()}.jpg")
    }

    // ---------- Algorithm implementations ----------

    /**
     * Align a set of frames to the first via integer-translation phase correlation
     * computed on a downsampled luminance image. Cheap and good enough for handheld bursts.
     */
    private fun alignFrames(frames: List<Bitmap>): List<Bitmap> {
        if (frames.size < 2) return frames
        val ref = frames[0]
        val refLum = downsampleLuminance(ref, 64)
        val aligned = mutableListOf(ref)
        for (i in 1 until frames.size) {
            val lum = downsampleLuminance(frames[i], 64)
            val (dx, dy) = bestShift(refLum, lum, maxShift = 6)
            val sx = dx * (ref.width / 64f); val sy = dy * (ref.height / 64f)
            aligned += translate(frames[i], sx, sy)
        }
        return aligned
    }

    private fun downsampleLuminance(b: Bitmap, size: Int): FloatArray {
        val small = Bitmap.createScaledBitmap(b, size, size, true)
        val out = FloatArray(size * size)
        val px = IntArray(size * size); small.getPixels(px, 0, size, 0, 0, size, size)
        for (i in px.indices) {
            val c = px[i]
            out[i] = (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f
        }
        return out
    }

    private fun bestShift(a: FloatArray, b: FloatArray, maxShift: Int): Pair<Int, Int> {
        val n = sqrt(a.size.toDouble()).toInt()
        var bestDx = 0; var bestDy = 0; var bestScore = Double.MAX_VALUE
        for (dy in -maxShift..maxShift) for (dx in -maxShift..maxShift) {
            var s = 0.0; var count = 0
            for (y in 0 until n) for (x in 0 until n) {
                val xx = x + dx; val yy = y + dy
                if (xx in 0 until n && yy in 0 until n) {
                    val d = a[y * n + x] - b[yy * n + xx]
                    s += d * d; count++
                }
            }
            val sc = if (count == 0) Double.MAX_VALUE else s / count
            if (sc < bestScore) { bestScore = sc; bestDx = dx; bestDy = dy }
        }
        return Pair(bestDx, bestDy)
    }

    private fun translate(src: Bitmap, dx: Float, dy: Float): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawBitmap(src, dx, dy, null)
        return out
    }

    /**
     * Mertens-style exposure fusion: per-pixel weights from contrast, saturation, well-exposedness.
     * Single-scale (no Laplacian pyramid) for clarity; pyramid version reduces halos.
     */
    private fun exposureFusion(frames: List<Bitmap>): Bitmap {
        val w = frames[0].width; val h = frames[0].height
        val accumR = FloatArray(w * h); val accumG = FloatArray(w * h); val accumB = FloatArray(w * h)
        val accumW = FloatArray(w * h)
        val px = IntArray(w * h)
        for (frame in frames) {
            frame.getPixels(px, 0, w, 0, 0, w, h)
            for (i in px.indices) {
                val c = px[i]
                val r = Color.red(c) / 255f; val g = Color.green(c) / 255f; val b = Color.blue(c) / 255f
                val lum = 0.299f * r + 0.587f * g + 0.114f * b
                // well-exposedness: gauss around 0.5
                val we = exp(-((lum - 0.5f).pow(2)) / (2 * 0.2f * 0.2f))
                // saturation: stddev across channels
                val mean = (r + g + b) / 3f
                val sat = sqrt(((r - mean).pow(2) + (g - mean).pow(2) + (b - mean).pow(2)) / 3f)
                // contrast: |laplacian|-ish via local diff (cheap: distance from mid)
                val con = abs(lum - 0.5f) + 0.01f
                val wgt = (we.pow(1.0f) * (sat + 0.01f).pow(1.0f) * con.pow(0.5f)).coerceAtLeast(1e-6f)
                accumR[i] += r * wgt; accumG[i] += g * wgt; accumB[i] += b * wgt; accumW[i] += wgt
            }
        }
        val out = IntArray(w * h)
        for (i in out.indices) {
            val wgt = accumW[i].coerceAtLeast(1e-6f)
            val r = (accumR[i] / wgt * 255f).toInt().coerceIn(0, 255)
            val g = (accumG[i] / wgt * 255f).toInt().coerceIn(0, 255)
            val b = (accumB[i] / wgt * 255f).toInt().coerceIn(0, 255)
            out[i] = Color.argb(255, r, g, b)
        }
        return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
    }

    /** Reinhard global tone map followed by mild S-curve. */
    private fun toneMap(b: Bitmap): Bitmap {
        val w = b.width; val h = b.height
        val px = IntArray(w * h); b.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) {
            val c = px[i]
            var r = Color.red(c) / 255f; var g = Color.green(c) / 255f; var bl = Color.blue(c) / 255f
            val l = 0.299f * r + 0.587f * g + 0.114f * bl
            val lOut = l / (1f + l)
            val gain = if (l > 1e-4f) lOut / l else 1f
            r *= gain; g *= gain; bl *= gain
            // S-curve
            r = sCurve(r); g = sCurve(g); bl = sCurve(bl)
            px[i] = Color.argb(255,
                (r * 255).toInt().coerceIn(0, 255),
                (g * 255).toInt().coerceIn(0, 255),
                (bl * 255).toInt().coerceIn(0, 255))
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    private fun sCurve(x: Float): Float {
        val k = 6f
        return 1f / (1f + exp(-k * (x - 0.5f)))
    }

    /** Per-pixel temporal mean across aligned frames (basic frame stacking). */
    private fun temporalMean(frames: List<Bitmap>): Bitmap {
        val w = frames[0].width; val h = frames[0].height
        val r = IntArray(w * h); val g = IntArray(w * h); val b = IntArray(w * h)
        val px = IntArray(w * h)
        for (f in frames) {
            f.getPixels(px, 0, w, 0, 0, w, h)
            for (i in px.indices) {
                r[i] += Color.red(px[i]); g[i] += Color.green(px[i]); b[i] += Color.blue(px[i])
            }
        }
        val n = frames.size
        for (i in px.indices) {
            px[i] = Color.argb(255, r[i] / n, g[i] / n, b[i] / n)
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    /** Cheap edge-preserving denoise: 3x3 box blur with luminance gating. */
    private fun edgePreservingDenoise(b: Bitmap): Bitmap {
        val w = b.width; val h = b.height
        val src = IntArray(w * h); b.getPixels(src, 0, w, 0, 0, w, h)
        val dst = src.copyOf()
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val ci = y * w + x
            val cl = lum(src[ci])
            var rs = 0f; var gs = 0f; var bs = 0f; var ws = 0f
            for (dy in -1..1) for (dx in -1..1) {
                val ni = (y + dy) * w + (x + dx)
                val nl = lum(src[ni])
                val wt = exp(-((nl - cl) * (nl - cl)) / 0.02f)
                rs += Color.red(src[ni]) * wt
                gs += Color.green(src[ni]) * wt
                bs += Color.blue(src[ni]) * wt
                ws += wt
            }
            dst[ci] = Color.argb(255, (rs / ws).toInt(), (gs / ws).toInt(), (bs / ws).toInt())
        }
        return Bitmap.createBitmap(dst, w, h, Bitmap.Config.ARGB_8888)
    }

    private fun lum(c: Int): Float =
        (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f

    /** Approximate depth map: center-bias + saliency from local color variance. */
    private fun approximateDepthMap(b: Bitmap): FloatArray {
        val w = b.width; val h = b.height
        val px = IntArray(w * h); b.getPixels(px, 0, w, 0, 0, w, h)
        val depth = FloatArray(w * h)
        val cx = w / 2f; val cy = h / 2f
        val maxD = sqrt(cx * cx + cy * cy)
        for (y in 0 until h) for (x in 0 until w) {
            val d = sqrt((x - cx).pow(2) + (y - cy).pow(2)) / maxD
            depth[y * w + x] = d.coerceIn(0f, 1f)
        }
        return depth
    }

    /** Apply variable Gaussian blur driven by depth map — sharper at depth=0, blurrier at depth=1. */
    private fun applyBokeh(src: Bitmap, depth: FloatArray, blurRadius: Float): Bitmap {
        val w = src.width; val h = src.height
        // Two pre-blurred levels (cheap), then per-pixel mix using depth.
        val lowBlur = gaussianBlur(src, blurRadius / 2)
        val highBlur = gaussianBlur(src, blurRadius)
        val a = IntArray(w * h); src.getPixels(a, 0, w, 0, 0, w, h)
        val l = IntArray(w * h); lowBlur.getPixels(l, 0, w, 0, 0, w, h)
        val hh = IntArray(w * h); highBlur.getPixels(hh, 0, w, 0, 0, w, h)
        val out = IntArray(w * h)
        for (i in out.indices) {
            val d = depth[i]
            val (c1, c2, t) = if (d < 0.5f) Triple(a[i], l[i], d * 2f) else Triple(l[i], hh[i], (d - 0.5f) * 2f)
            out[i] = lerpColor(c1, c2, t)
        }
        return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
    }

    private fun lerpColor(a: Int, b: Int, t: Float): Int {
        val r = (Color.red(a) * (1 - t) + Color.red(b) * t).toInt()
        val g = (Color.green(a) * (1 - t) + Color.green(b) * t).toInt()
        val bl = (Color.blue(a) * (1 - t) + Color.blue(b) * t).toInt()
        return Color.argb(255, r, g, bl)
    }

    /** Fast separable Gaussian via RenderScript-equivalent CPU loop (small kernel). */
    private fun gaussianBlur(src: Bitmap, radius: Float): Bitmap {
        val r = radius.toInt().coerceAtLeast(1)
        val k = FloatArray(r * 2 + 1)
        val sigma = radius / 2f
        var sum = 0f
        for (i in -r..r) { val v = exp(-(i * i) / (2 * sigma * sigma)); k[i + r] = v; sum += v }
        for (i in k.indices) k[i] /= sum
        val w = src.width; val h = src.height
        val px = IntArray(w * h); src.getPixels(px, 0, w, 0, 0, w, h)
        val tmp = IntArray(w * h)
        // Horizontal
        for (y in 0 until h) for (x in 0 until w) {
            var rr = 0f; var gg = 0f; var bb = 0f
            for (i in -r..r) {
                val xx = (x + i).coerceIn(0, w - 1)
                val c = px[y * w + xx]; val wt = k[i + r]
                rr += Color.red(c) * wt; gg += Color.green(c) * wt; bb += Color.blue(c) * wt
            }
            tmp[y * w + x] = Color.argb(255, rr.toInt(), gg.toInt(), bb.toInt())
        }
        val out = IntArray(w * h)
        // Vertical
        for (y in 0 until h) for (x in 0 until w) {
            var rr = 0f; var gg = 0f; var bb = 0f
            for (i in -r..r) {
                val yy = (y + i).coerceIn(0, h - 1)
                val c = tmp[yy * w + x]; val wt = k[i + r]
                rr += Color.red(c) * wt; gg += Color.green(c) * wt; bb += Color.blue(c) * wt
            }
            out[y * w + x] = Color.argb(255, rr.toInt(), gg.toInt(), bb.toInt())
        }
        return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
    }

    private fun unsharpMask(src: Bitmap, amount: Float): Bitmap {
        val blurred = gaussianBlur(src, 2f)
        val w = src.width; val h = src.height
        val a = IntArray(w * h); src.getPixels(a, 0, w, 0, 0, w, h)
        val b = IntArray(w * h); blurred.getPixels(b, 0, w, 0, 0, w, h)
        val out = IntArray(w * h)
        for (i in out.indices) {
            val dr = Color.red(a[i]) - Color.red(b[i])
            val dg = Color.green(a[i]) - Color.green(b[i])
            val db = Color.blue(a[i]) - Color.blue(b[i])
            val r = (Color.red(a[i]) + dr * amount).toInt().coerceIn(0, 255)
            val g = (Color.green(a[i]) + dg * amount).toInt().coerceIn(0, 255)
            val bl = (Color.blue(a[i]) + db * amount).toInt().coerceIn(0, 255)
            out[i] = Color.argb(255, r, g, bl)
        }
        return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
    }

    /** Gray-world white balance: scale channels so their means equalize. */
    private fun grayWorldWhiteBalance(src: Bitmap): Bitmap {
        val w = src.width; val h = src.height
        val px = IntArray(w * h); src.getPixels(px, 0, w, 0, 0, w, h)
        var rSum = 0L; var gSum = 0L; var bSum = 0L
        for (c in px) { rSum += Color.red(c); gSum += Color.green(c); bSum += Color.blue(c) }
        val n = px.size.toDouble()
        val rM = rSum / n; val gM = gSum / n; val bM = bSum / n
        val avg = (rM + gM + bM) / 3.0
        val gr = (avg / rM).toFloat(); val gg = (avg / gM).toFloat(); val gb = (avg / bM).toFloat()
        for (i in px.indices) {
            val c = px[i]
            val r = (Color.red(c) * gr).toInt().coerceIn(0, 255)
            val g = (Color.green(c) * gg).toInt().coerceIn(0, 255)
            val b = (Color.blue(c) * gb).toInt().coerceIn(0, 255)
            px[i] = Color.argb(255, r, g, b)
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    /** Default enhancement chain for single-frame photos. */
    private fun enhance(src: Bitmap): Bitmap {
        val wb = grayWorldWhiteBalance(src)
        val toned = toneMap(wb)
        return unsharpMask(toned, 0.3f)
    }

    // ---------- Helpers ----------

    private fun decode(jpeg: ByteArray): Bitmap =
        BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size)

    private fun nv21ToBitmap(nv21: ByteArray, w: Int, h: Int): Bitmap {
        val yuv = android.graphics.YuvImage(nv21, ImageFormat.NV21, w, h, null)
        val bos = ByteArrayOutputStream()
        yuv.compressToJpeg(android.graphics.Rect(0, 0, w, h), 92, bos)
        val bytes = bos.toByteArray()
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    }

    private fun saveBitmap(b: Bitmap, name: String) {
        val f = File(outDir, name)
        FileOutputStream(f).use { b.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        writeExif(f)
        Log.i(TAG, "Saved ${f.absolutePath}")
    }

    private fun saveJpeg(bytes: ByteArray, name: String) {
        val f = File(outDir, name)
        f.writeBytes(bytes)
        writeExif(f)
    }

    private fun writeExif(f: File) {
        runCatching {
            val exif = ExifInterface(f.absolutePath)
            exif.setAttribute(ExifInterface.TAG_MAKE, "ProCam")
            exif.setAttribute(ExifInterface.TAG_MODEL, "Computational Pipeline")
            exif.setAttribute(ExifInterface.TAG_SOFTWARE, "ProCam 1.0")
            exif.saveAttributes()
        }
    }

    private fun ts() = System.currentTimeMillis().toString()
}
