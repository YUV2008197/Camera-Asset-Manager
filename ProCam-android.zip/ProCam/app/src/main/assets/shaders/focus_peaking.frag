#version 300 es
precision highp float;
in vec2 vTex;
uniform sampler2D uTex;
uniform vec2 uTexel;
out vec4 outColor;

// Sobel edge detector; pixels with strong edges and mid luminance are highlighted yellow.
void main() {
    float tl = dot(texture(uTex, vTex + vec2(-uTexel.x, -uTexel.y)).rgb, vec3(0.299,0.587,0.114));
    float t  = dot(texture(uTex, vTex + vec2( 0.0,      -uTexel.y)).rgb, vec3(0.299,0.587,0.114));
    float tr = dot(texture(uTex, vTex + vec2( uTexel.x, -uTexel.y)).rgb, vec3(0.299,0.587,0.114));
    float l  = dot(texture(uTex, vTex + vec2(-uTexel.x,  0.0     )).rgb, vec3(0.299,0.587,0.114));
    float r  = dot(texture(uTex, vTex + vec2( uTexel.x,  0.0     )).rgb, vec3(0.299,0.587,0.114));
    float bl = dot(texture(uTex, vTex + vec2(-uTexel.x,  uTexel.y)).rgb, vec3(0.299,0.587,0.114));
    float b  = dot(texture(uTex, vTex + vec2( 0.0,       uTexel.y)).rgb, vec3(0.299,0.587,0.114));
    float br = dot(texture(uTex, vTex + vec2( uTexel.x,  uTexel.y)).rgb, vec3(0.299,0.587,0.114));
    float gx = -tl - 2.0*l - bl + tr + 2.0*r + br;
    float gy = -tl - 2.0*t - tr + bl + 2.0*b + br;
    float mag = length(vec2(gx, gy));
    vec3 base = texture(uTex, vTex).rgb;
    vec3 peak = mix(base, vec3(1.0, 0.85, 0.0), step(0.35, mag));
    outColor = vec4(peak, 1.0);
}
