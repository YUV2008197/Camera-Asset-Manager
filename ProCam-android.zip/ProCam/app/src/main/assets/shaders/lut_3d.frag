#version 300 es
precision highp float;
in vec2 vTex;
uniform sampler2D uTex;
uniform sampler3D uLut;     // 33^3 LUT for cinematic grading
uniform float uIntensity;
out vec4 outColor;

void main() {
    vec3 c = texture(uTex, vTex).rgb;
    vec3 graded = texture(uLut, c).rgb;
    outColor = vec4(mix(c, graded, uIntensity), 1.0);
}
