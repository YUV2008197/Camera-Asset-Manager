#version 300 es
precision highp float;
in vec2 vTex;
uniform sampler2D uTex;
out vec4 outColor;

// Reinhard tone map + mild S-curve, matches CPU pipeline.
float sCurve(float x) {
    return 1.0 / (1.0 + exp(-6.0 * (x - 0.5)));
}

void main() {
    vec3 c = texture(uTex, vTex).rgb;
    float l = dot(c, vec3(0.299, 0.587, 0.114));
    float lOut = l / (1.0 + l);
    c *= (l > 1e-4) ? (lOut / l) : 1.0;
    c = vec3(sCurve(c.r), sCurve(c.g), sCurve(c.b));
    outColor = vec4(c, 1.0);
}
