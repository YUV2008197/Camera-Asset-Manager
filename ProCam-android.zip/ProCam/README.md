# ProCam — Computational Photography Camera (Android)

Production-grade Android camera app skeleton built on **Camera2 API** with an
implemented computational photography pipeline (HDR, Night Mode, Portrait
Bokeh, Tone Mapping, Denoise, White Balance, Sharpening) plus GLSL shaders
for GPU acceleration.

> ⚠️ This project was **scaffolded as source code only** — it has not been
> compiled. Open it in Android Studio (Hedgehog or newer), let Gradle sync,
> resolve any device-specific quirks, and build.

---

## 1. Project Structure

```
ProCam/
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle.kts
    └── src/main/
        ├── AndroidManifest.xml
        ├── assets/shaders/             # GLSL shaders (tone map, focus peaking, 3D LUT)
        ├── res/                        # layouts, themes, drawables
        └── java/com/procam/app/
            ├── ui/
            │   ├── MainActivity.kt
            │   ├── AutoFitTextureView.kt
            │   └── HistogramView.kt
            ├── camera/
            │   ├── CameraController.kt # Camera2 session, ZSL, manual controls, burst
            │   ├── CaptureMode.kt
            │   └── YuvUtil.kt
            └── processing/
                └── ImagePipeline.kt    # All computational photography algorithms
```

## 2. Setup

1. Install **Android Studio Hedgehog (2023.1.1)** or newer.
2. Install **Android SDK 34** and the Gradle 8.7 wrapper (handled automatically).
3. `git clone` (or unzip) this project, then `File → Open` the `ProCam/` folder.
4. Plug in a **physical Android device** with `adb` enabled (Camera2 RAW does
   not work on emulators).
5. Build & run the `app` configuration. Grant Camera + Microphone permissions
   on first launch.

Outputs are written to `/Android/data/com.procam.app/files/ProCam/`.

## 3. How each feature works

### 3.1 Camera2 + Zero Shutter Lag
`CameraController` opens the back camera that advertises the `RAW` capability.
A `CameraCaptureSession` targets four surfaces simultaneously:
- **Preview** (`TextureView`) — what the user sees
- **YUV ImageReader** — drives histogram, ZSL ring buffer, scene analysis
- **RAW ImageReader** — sensor frames for HDR/Night/RAW saving
- **JPEG ImageReader** — final fallback / burst capture sink

Every preview frame is converted to NV21 and pushed to a 6-deep
`ArrayDeque<YuvFrame>` (the **ZSL buffer**). When the shutter is pressed in
Photo mode, we pull the *most recent* buffered frame instead of issuing a new
capture — giving truly zero-latency stills.

### 3.2 Multi-frame HDR
`captureHdrBurst(n)` builds a symmetric EV bracket (-2…+2) clamped to the
sensor's exposure range, then issues `captureBurst(...)`. Frames flow into
`ImagePipeline.processHdr`:

1. **Alignment** — `alignFrames` downsamples each frame to a 64×64 luminance
   image and runs an integer-shift phase correlation (SSD search ±6 px).
   Translates each frame to match the reference. Rotation isn't compensated
   in this scaffold — for real handheld merging, replace with ORB feature
   matching + homography (OpenCV).
2. **Exposure fusion** (Mertens 2007) — per-pixel weights from
   `well_exposedness × saturation × contrast`. Single-scale here for clarity;
   Laplacian-pyramid blending eliminates halos in production.
3. **Tone mapping** — Reinhard global operator + 6-slope sigmoid S-curve.
4. **Sharpening** — unsharp mask (radius 2, amount 0.4).

### 3.3 Night Mode
`captureNightStack(n)` sets ISO to roughly 2× the sensor floor and fixes
exposure to 250 ms per frame, then bursts 7 frames. Pipeline:

1. Translation alignment (same as HDR).
2. **Temporal mean stack** — averages aligned frames per pixel. SNR scales
   with √N, so 7 frames ≈ +2.8 stops of clean light gathering.
3. **Edge-preserving denoise** — 3×3 weighted box where weights fall off
   exponentially with luminance distance (cheap bilateral approximation).
4. Standard enhance chain (white balance + tone map + sharpen).

Ghost removal is approximated by alignment quality — for moving subjects,
add a per-frame motion mask (compute residual after alignment, discard
frames with high residual in that region).

### 3.4 Portrait (Depth Bokeh)
Without a depth sensor we approximate depth via:
- **Center-bias** — Euclidean distance from frame center, normalized.
- (Hook in saliency / segmentation here for production — TFLite DeepLab
  or the Camera2 `DEPTH16` stream on dual-camera devices.)

`applyBokeh` precomputes two Gaussian-blurred copies (low + high radius) and
blends per pixel using the depth value — sharp at depth=0, fully blurred at
depth=1, with a smooth transition.

### 3.5 Smart Exposure & Scene Detection
The live histogram view (`HistogramView`) samples Y plane every Nth pixel and
maintains a 64-bin EMA. The `ImagePipeline` exposes `enhance()` which white-
balances (gray-world), tone-maps, and sharpens — call sites can branch on
histogram statistics for portrait/food/landscape/text presets.

### 3.6 White Balance
Gray-world: scale R/G/B channels so all means converge to the global mean.
Replace with white-patch or a learned model for accuracy in mixed lighting.

### 3.7 Real-time GPU shaders
`assets/shaders/`:
- `tone_map.frag` — Reinhard + S-curve, identical math to CPU version.
- `focus_peaking.frag` — Sobel edge detector, pixels above a magnitude
  threshold are tinted yellow.
- `lut_3d.frag` — samples a 33³ 3D LUT for cinematic grading (load `.cube`
  files into a `GL_TEXTURE_3D`).
- `preview_passthrough.vert` — shared fullscreen quad vertex shader.

Wire these into a `GLSurfaceView` or render through `MediaCodec` for the
video pipeline.

### 3.8 Video
`startVideo` configures `MediaRecorder` for 4K @ 30 fps H.264, 60 Mbps. To
add EIS + LUT grading, recreate the session targeting an `OpenGL` surface
that consumes the camera frames, applies shaders, then writes to
`MediaCodec.createInputSurface()`.

### 3.9 Manual controls
`MainActivity` exposes three sliders mapped to:
- ISO → `SENSOR_SENSITIVITY` (clamped to `SENSOR_INFO_SENSITIVITY_RANGE`)
- Shutter → `SENSOR_EXPOSURE_TIME` (log-scaled across `SENSOR_INFO_EXPOSURE_TIME_RANGE`)
- Focus → `LENS_FOCUS_DISTANCE` (0 = ∞, slider × `LENS_INFO_MINIMUM_FOCUS_DISTANCE`)

Setting any one switches `CONTROL_AE_MODE_OFF`/`CONTROL_AF_MODE_OFF`.

### 3.10 File management & EXIF
All processed outputs land in `getExternalFilesDir("ProCam")`. EXIF is
written via AndroidX `ExifInterface` (Make/Model/Software). RAW frames are
dumped as `.raw` byte blobs — to produce real DNGs, port Google's
`DngCreator` (one-liner via `DngCreator(characteristics, captureResult).writeImage(...)`).

## 4. Performance notes

The reference algorithms in `ImagePipeline` run on the JVM with `IntArray`
pixel access — fine for prototyping at ~12 MP, but expect **multi-second**
HDR merges. To reach iPhone-class speed:

| Stage             | Recommended backend        |
|-------------------|----------------------------|
| Align             | OpenCV `findTransformECC` or ORB+RANSAC (NDK) |
| Exposure fusion   | RenderScript / Vulkan compute / GLSL FBO chain |
| Denoise           | NDK with NEON intrinsics or NNAPI bilateral |
| Bokeh             | TFLite segmentation + GLSL shader |
| Tone map / WB     | Already provided as fragment shaders |

Camera2 work runs on a dedicated `HandlerThread`; capture entry points are
`suspend fun` on `Dispatchers.IO`.

## 5. Future upgrades

- **AI Super-Resolution** — TFLite ESRGAN-lite as a final stage for crops/zoom.
- **RAW Deep-Learning Enhancement** — ONNX runtime model trained on (RAW, edited JPEG) pairs.
- **Real-time Segmentation** — MediaPipe SelfieSegmentation for true portrait depth + sky replacement.
- **Semantic tone mapping** — per-region exposure (face brightening, sky protection).
- **Astro mode** — 30 s exposures with star-trail compensation via per-frame star alignment.
- **HDR10 video** — switch to 10-bit HEVC + BT.2100 PQ LUTs.

---

© ProCam reference scaffold. MIT-style — adapt freely.
